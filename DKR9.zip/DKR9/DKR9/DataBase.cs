﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;


namespace DKR9
{
    internal class DataBase
    {
        public static string DBConnect = "server = bvxxvawxtmkbe40mxmdx-mysql.services.clever-cloud.com; user = u53ispl8vlqjchqu; password = 94PIAIBXrenYhYjhlSxj; database = bvxxvawxtmkbe40mxmdx";
        static public MySqlDataAdapter msDataAdapter;
        static MySqlConnection myconnect;
        static public MySqlCommand msCommand;

        public static bool ConnectionDB()
        {
            try
            {
                myconnect = new MySqlConnection(DBConnect);
                myconnect.Open();
                msCommand = new MySqlCommand();
                msCommand.Connection = myconnect;
                msDataAdapter = new MySqlDataAdapter(msCommand);
                return true;
            }
            catch
            {
                MessageBox.Show("Ошибка соединения с БД", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error); 
                return false;
            }
        }

        public static void CloseDB()
        {
            myconnect.Close();
        }

        public MySqlConnection getConnection { get { return myconnect; } }
    }
}
