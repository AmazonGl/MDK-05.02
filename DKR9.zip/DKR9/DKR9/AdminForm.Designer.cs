﻿namespace DKR9
{
    partial class AdminForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            действияToolStripMenuItem = new ToolStripMenuItem();
            загрузитьToolStripMenuItem = new ToolStripMenuItem();
            изменитьToolStripMenuItem = new ToolStripMenuItem();
            удалитьToolStripMenuItem = new ToolStripMenuItem();
            перейтиКПросмотруДанныхToolStripMenuItem = new ToolStripMenuItem();
            выходToolStripMenuItem = new ToolStripMenuItem();
            обПрограммеToolStripMenuItem = new ToolStripMenuItem();
            выбранныйToolStripMenuItem = new ToolStripMenuItem();
            всеДанныеToolStripMenuItem = new ToolStripMenuItem();
            label1 = new Label();
            dataGrid = new DataGridView();
            panel1 = new Panel();
            textCom = new TextBox();
            label6 = new Label();
            textActer = new TextBox();
            label5 = new Label();
            textChest = new TextBox();
            label4 = new Label();
            textName = new TextBox();
            label3 = new Label();
            textYear = new TextBox();
            label2 = new Label();
            label7 = new Label();
            textSearch = new TextBox();
            btnSearch = new Button();
            btnRetrieve = new Button();
            btnDelete = new Button();
            btnNew = new Button();
            btnClear = new Button();
            menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGrid).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { действияToolStripMenuItem, выходToolStripMenuItem, обПрограммеToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(868, 24);
            menuStrip1.TabIndex = 1;
            menuStrip1.Text = "menuStrip1";
            // 
            // действияToolStripMenuItem
            // 
            действияToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { загрузитьToolStripMenuItem, изменитьToolStripMenuItem, удалитьToolStripMenuItem, перейтиКПросмотруДанныхToolStripMenuItem });
            действияToolStripMenuItem.Name = "действияToolStripMenuItem";
            действияToolStripMenuItem.Size = new Size(70, 20);
            действияToolStripMenuItem.Text = "Действия";
            // 
            // загрузитьToolStripMenuItem
            // 
            загрузитьToolStripMenuItem.Name = "загрузитьToolStripMenuItem";
            загрузитьToolStripMenuItem.Size = new Size(238, 22);
            // 
            // изменитьToolStripMenuItem
            // 
            изменитьToolStripMenuItem.Name = "изменитьToolStripMenuItem";
            изменитьToolStripMenuItem.Size = new Size(238, 22);
            // 
            // удалитьToolStripMenuItem
            // 
            удалитьToolStripMenuItem.Name = "удалитьToolStripMenuItem";
            удалитьToolStripMenuItem.Size = new Size(238, 22);
            // 
            // перейтиКПросмотруДанныхToolStripMenuItem
            // 
            перейтиКПросмотруДанныхToolStripMenuItem.Name = "перейтиКПросмотруДанныхToolStripMenuItem";
            перейтиКПросмотруДанныхToolStripMenuItem.Size = new Size(238, 22);
            перейтиКПросмотруДанныхToolStripMenuItem.Text = "Перейти к просмотру данных";
            // 
            // выходToolStripMenuItem
            // 
            выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            выходToolStripMenuItem.Size = new Size(54, 20);
            выходToolStripMenuItem.Text = "Выход";
            выходToolStripMenuItem.Click += выходToolStripMenuItem_Click;
            // 
            // обПрограммеToolStripMenuItem
            // 
            обПрограммеToolStripMenuItem.Name = "обПрограммеToolStripMenuItem";
            обПрограммеToolStripMenuItem.Size = new Size(101, 20);
            обПрограммеToolStripMenuItem.Text = "Об программе";
            обПрограммеToolStripMenuItem.Click += обПрограммеToolStripMenuItem_Click;
            // 
            // выбранныйToolStripMenuItem
            // 
            выбранныйToolStripMenuItem.Name = "выбранныйToolStripMenuItem";
            выбранныйToolStripMenuItem.Size = new Size(180, 22);
            выбранныйToolStripMenuItem.Text = "Выбранный";
            // 
            // всеДанныеToolStripMenuItem
            // 
            всеДанныеToolStripMenuItem.Name = "всеДанныеToolStripMenuItem";
            всеДанныеToolStripMenuItem.Size = new Size(180, 22);
            всеДанныеToolStripMenuItem.Text = "Все данные";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(0, 231);
            label1.Name = "label1";
            label1.Size = new Size(141, 45);
            label1.TabIndex = 2;
            label1.Text = "Данные:";
            label1.Click += label1_Click;
            // 
            // dataGrid
            // 
            dataGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGrid.Location = new Point(0, 279);
            dataGrid.Name = "dataGrid";
            dataGrid.RowTemplate.Height = 25;
            dataGrid.Size = new Size(868, 252);
            dataGrid.TabIndex = 3;
            dataGrid.CellContentClick += dataGrid_CellContentClick;
            // 
            // panel1
            // 
            panel1.Controls.Add(textCom);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(textActer);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(textChest);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(textName);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(textYear);
            panel1.Controls.Add(label2);
            panel1.Location = new Point(12, 27);
            panel1.Name = "panel1";
            panel1.Size = new Size(844, 212);
            panel1.TabIndex = 4;
            // 
            // textCom
            // 
            textCom.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            textCom.Location = new Point(237, 174);
            textCom.Name = "textCom";
            textCom.Size = new Size(253, 33);
            textCom.TabIndex = 14;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(32, 174);
            label6.Name = "label6";
            label6.Size = new Size(132, 25);
            label6.TabIndex = 13;
            label6.Text = "Комментарий";
            // 
            // textActer
            // 
            textActer.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            textActer.Location = new Point(237, 135);
            textActer.Name = "textActer";
            textActer.Size = new Size(253, 33);
            textActer.TabIndex = 12;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(32, 135);
            label5.Name = "label5";
            label5.Size = new Size(139, 25);
            label5.TabIndex = 11;
            label5.Text = "Главный актер";
            // 
            // textChest
            // 
            textChest.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            textChest.Location = new Point(237, 96);
            textChest.Name = "textChest";
            textChest.Size = new Size(253, 33);
            textChest.TabIndex = 10;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(32, 96);
            label4.Name = "label4";
            label4.Size = new Size(187, 25);
            label4.TabIndex = 9;
            label4.Text = "Количесство частей";
            // 
            // textName
            // 
            textName.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            textName.Location = new Point(237, 54);
            textName.Name = "textName";
            textName.Size = new Size(253, 33);
            textName.TabIndex = 8;
            textName.TextChanged += textBox2_TextChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(32, 57);
            label3.Name = "label3";
            label3.Size = new Size(167, 25);
            label3.TabIndex = 7;
            label3.Text = "Название фильма";
            // 
            // textYear
            // 
            textYear.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            textYear.Location = new Point(237, 15);
            textYear.Name = "textYear";
            textYear.Size = new Size(253, 33);
            textYear.TabIndex = 6;
            textYear.Text = "\r\n";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(32, 18);
            label2.Name = "label2";
            label2.Size = new Size(42, 25);
            label2.TabIndex = 5;
            label2.Text = "Год";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label7.Location = new Point(169, 247);
            label7.Name = "label7";
            label7.Size = new Size(70, 25);
            label7.TabIndex = 15;
            label7.Text = "Поиск:";
            // 
            // textSearch
            // 
            textSearch.Location = new Point(259, 247);
            textSearch.Name = "textSearch";
            textSearch.Size = new Size(597, 23);
            textSearch.TabIndex = 16;
            textSearch.TextChanged += textSearch_TextChanged;
            // 
            // btnSearch
            // 
            btnSearch.Location = new Point(704, 537);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(75, 23);
            btnSearch.TabIndex = 17;
            btnSearch.Text = "Поиск";
            btnSearch.UseVisualStyleBackColor = true;
            btnSearch.Click += btnSave_Click;
            // 
            // btnRetrieve
            // 
            btnRetrieve.Location = new Point(623, 537);
            btnRetrieve.Name = "btnRetrieve";
            btnRetrieve.Size = new Size(75, 23);
            btnRetrieve.TabIndex = 18;
            btnRetrieve.Text = "Показать";
            btnRetrieve.UseVisualStyleBackColor = true;
            btnRetrieve.Click += btnCancel_Click;
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(542, 537);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(75, 23);
            btnDelete.TabIndex = 19;
            btnDelete.Text = "Удалить";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += button3_Click;
            // 
            // btnNew
            // 
            btnNew.Location = new Point(461, 537);
            btnNew.Name = "btnNew";
            btnNew.Size = new Size(75, 23);
            btnNew.TabIndex = 20;
            btnNew.Text = "Добавить";
            btnNew.UseVisualStyleBackColor = true;
            btnNew.Click += btnNew_Click;
            // 
            // btnClear
            // 
            btnClear.Location = new Point(785, 537);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(75, 23);
            btnClear.TabIndex = 21;
            btnClear.Text = "Очистить";
            btnClear.UseVisualStyleBackColor = true;
            btnClear.Click += btnClear_Click;
            // 
            // AdminForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(868, 566);
            Controls.Add(btnClear);
            Controls.Add(btnNew);
            Controls.Add(btnDelete);
            Controls.Add(btnRetrieve);
            Controls.Add(btnSearch);
            Controls.Add(textSearch);
            Controls.Add(label7);
            Controls.Add(panel1);
            Controls.Add(dataGrid);
            Controls.Add(label1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "AdminForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Админ панель";
            Load += AdminForm_Load;
            Shown += AdminForm_Shown;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGrid).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnSearch;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem действияToolStripMenuItem;
        private ToolStripMenuItem выходToolStripMenuItem;
        private ToolStripMenuItem обПрограммеToolStripMenuItem;
        private Label label1;
        private DataGridView dataGrid;
        private ToolStripMenuItem загрузитьToolStripMenuItem;
        private ToolStripMenuItem изменитьToolStripMenuItem;
        private ToolStripMenuItem удалитьToolStripMenuItem;
        private ToolStripMenuItem выбранныйToolStripMenuItem;
        private ToolStripMenuItem всеДанныеToolStripMenuItem;
        private ToolStripMenuItem перейтиКПросмотруДанныхToolStripMenuItem;
        private Panel panel1;
        private TextBox textActer;
        private Label label5;
        private TextBox textChest;
        private Label label4;
        private TextBox textName;
        private Label label3;
        private TextBox textYear;
        private Label label2;
        private TextBox textCom;
        private Label label6;
        private Label label7;
        private TextBox textSearch;
        private Button btnRetrieve;
        private Button btnDelete;
        private Button btnNew;
        private Button button1;
        private Button btnClear;
    }
}