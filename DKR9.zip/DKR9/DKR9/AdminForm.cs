﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DKR9
{
    public partial class AdminForm : Form
    {
        static string conString = "Server=bvxxvawxtmkbe40mxmdx-mysql.services.clever-cloud.com;Database=bvxxvawxtmkbe40mxmdx;Uid=u53ispl8vlqjchqu;Pwd=94PIAIBXrenYhYjhlSxj;";
        MySqlConnection con = new MySqlConnection(conString);
        MySqlCommand cmd;
        MySqlDataAdapter adapter;
        DataTable dt = new DataTable();
        public AdminForm()
        {
            InitializeComponent();

            //DATAGRIDVIEW PROPERTIES
            dataGrid.ColumnCount = 6;
            dataGrid.Columns[0].Name = "ID";
            dataGrid.Columns[1].Name = "Год";
            dataGrid.Columns[2].Name = "Название фильма";
            dataGrid.Columns[3].Name = "Количество частей";
            dataGrid.Columns[4].Name = "Главный герой";
            dataGrid.Columns[5].Name = "Комментарий";

            dataGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGrid.ReadOnly = true;
            //SELECTION MODE
            dataGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGrid.MultiSelect = false;

            dataGrid.SelectionChanged += dataGrid_SelectionChanged;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form = new Form1();
            form.Show();
        }

        //INSERT INTO DB
        private void add(string year, string name, string chest, string acters, string com)
        {
            //SQL STMT
            string sql = "INSERT INTO `DKR9`(`Год`, `Название фильма`, `Количество частей`, `Главный актер`, `Комментарий`) VALUES(@YEAR,@NAME,@CHEST,@ACTERS,@COM)";
            cmd = new MySqlCommand(sql, con);

            //ADD PARAMETERS
            cmd.Parameters.AddWithValue("@YEAR", year);
            cmd.Parameters.AddWithValue("@NAME", name);
            cmd.Parameters.AddWithValue("@CHEST", chest);
            cmd.Parameters.AddWithValue("@ACTERS", acters);
            cmd.Parameters.AddWithValue("@COM", com);
            //OPEN CON AND EXEC insert
            try
            {
                con.Open();

                if (cmd.ExecuteNonQuery() > 0)
                {
                    clearTxts();
                    MessageBox.Show("Добавление прошло успешно!");
                }

                con.Close();

                retrieve();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                con.Close();
            }
        }

        //ADD TO DGVIEW
        private void populate(String id, String year, string name, string chest, string acters, string com)
        {
            dataGrid.Rows.Add(id, year, name, chest, acters, com);
        }

        //RETRIEVE FROM DB
        private void retrieve()
        {
            dataGrid.Rows.Clear();

            //SQL запрос
            string sql = "SELECT * FROM DKR9 ";
            cmd = new MySqlCommand(sql, con);

            try
            {
                con.Open();

                adapter = new MySqlDataAdapter(cmd);

                adapter.Fill(dt);

                //LOOP THRU DT
                foreach (DataRow row in dt.Rows)
                {
                    populate(row[0].ToString(), row[1].ToString(), row[2].ToString(), row[3].ToString(), row[4].ToString(), row[5].ToString());
                }

                con.Close();

                //CLEAR DT
                dt.Rows.Clear();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
                con.Close();
            }
        }

        //Удаление
        private void delete(int id)
        {
            //SQL запрос
            string sql = "DELETE FROM DKR9 WHERE ID=" + id + "";
            cmd = new MySqlCommand(sql, con);

            try
            {
                con.Open();

                adapter = new MySqlDataAdapter(cmd);

                adapter.DeleteCommand = con.CreateCommand();

                adapter.DeleteCommand.CommandText = sql;

                // Подтверждение
                if (MessageBox.Show("Вы уверены, что хотите удалить запись?", "Удаление", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) == DialogResult.OK)
                {
                    if (cmd.ExecuteNonQuery() > 0)
                    {
                        clearTxts();
                        MessageBox.Show("Удаление прошло успешно!");
                    }
                }

                con.Close();

                retrieve();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                con.Close();
            }

        }

        private void RetrieveFilteredData(string searchTerm)
        {
            dataGrid.Rows.Clear();

            // SQL запрос
            string sql = "SELECT * FROM DKR9 WHERE `Год` LIKE @SearchTerm";
            cmd = new MySqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@SearchTerm", "%" + searchTerm + "%");

            try
            {
                con.Open();
                adapter = new MySqlDataAdapter(cmd);
                adapter.Fill(dt);

                foreach (DataRow row in dt.Rows)
                {
                    populate(row[0].ToString(), row[1].ToString(), row[2].ToString(), row[3].ToString(), row[4].ToString(), row[5].ToString());
                }

                con.Close();
                dt.Rows.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                con.Close();
            }
        }


        //Очистка
        private void clearTxts()
        {
            textYear.Text = "";
            textName.Text = "";
            textChest.Text = "";
            textActer.Text = "";
            textCom.Text = "";
            textSearch.Text = "";
        }

        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {
            textYear.Text = dataGrid.SelectedRows[0].Cells[1].Value.ToString();
            textName.Text = dataGrid.SelectedRows[0].Cells[2].Value.ToString();
            textChest.Text = dataGrid.SelectedRows[0].Cells[3].Value.ToString();
            textActer.Text = dataGrid.SelectedRows[0].Cells[4].Value.ToString();
            textCom.Text = dataGrid.SelectedRows[0].Cells[5].Value.ToString();
        }


        private void AdminForm_Load(object sender, EventArgs e)
        {
            // LoadTableData();
        }

        private void AdminForm_Shown(object sender, EventArgs e)
        {
            // LoadTableData();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form = new Form1();
            form.Show();
        }

        private void обПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Программа для обрааботки запросов, из базы данных MySQL", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }


        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            String selected = dataGrid.SelectedRows[0].Cells[0].Value.ToString();
            int id = Convert.ToInt32(selected);

            delete(id);
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            add(textYear.Text, textName.Text, textChest.Text, textActer.Text, textCom.Text);
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            retrieve();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string searchTerm = textSearch.Text;
            RetrieveFilteredData(searchTerm);
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            dataGrid.Rows.Clear();
            clearTxts();
        }

        private void dataGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGrid_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGrid.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGrid.SelectedRows[0];
                if (selectedRow.Cells[1].Value != null)
                    textYear.Text = selectedRow.Cells[1].Value.ToString();
                else
                    textYear.Text = string.Empty;

                if (selectedRow.Cells[2].Value != null)
                    textName.Text = selectedRow.Cells[2].Value.ToString();
                else
                    textName.Text = string.Empty;

                if (selectedRow.Cells[3].Value != null)
                    textChest.Text = selectedRow.Cells[3].Value.ToString();
                else
                    textChest.Text = string.Empty;

                if (selectedRow.Cells[4].Value != null)
                    textActer.Text = selectedRow.Cells[4].Value.ToString();
                else
                    textActer.Text = string.Empty;

                if (selectedRow.Cells[5].Value != null)
                    textCom.Text = selectedRow.Cells[5].Value.ToString();
                else
                    textCom.Text = string.Empty;
            }
        }

        private void textSearch_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
