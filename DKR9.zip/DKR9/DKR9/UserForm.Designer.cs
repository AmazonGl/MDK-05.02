﻿namespace DKR9
{
    partial class UserForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            dataGridUS = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dataGridUS).BeginInit();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(681, 427);
            button1.Name = "button1";
            button1.Size = new Size(118, 23);
            button1.TabIndex = 0;
            button1.Text = "Назад";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // dataGridUS
            // 
            dataGridUS.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridUS.Location = new Point(0, 0);
            dataGridUS.Name = "dataGridUS";
            dataGridUS.RowTemplate.Height = 25;
            dataGridUS.Size = new Size(799, 421);
            dataGridUS.TabIndex = 1;
            // 
            // UserForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(dataGridUS);
            Controls.Add(button1);
            Name = "UserForm";
            Text = "Пользовательская панель";
            Load += UserForm_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridUS).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Button button1;
        private DataGridView dataGridUS;
    }
}