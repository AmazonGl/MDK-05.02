﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DKR9
{
    public partial class UserForm : Form
    {
        public UserForm()
        {
            InitializeComponent();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form = new Form1();
            form.Show();
        }

        private void UserForm_Load(object sender, EventArgs e)
        {
            LoadTableData();
        }

        private void LoadTableData()
        {
            // Создайте таблицу DataTable для хранения данных
            DataTable dataTable = new DataTable();
            dataGridUS.ReadOnly = true;

            // Connect to the database
            if (DataBase.ConnectionDB())
            {
                try
                {
                    // Создайте запрос SELECT для получения данных из таблицыtable
                    string query = "SELECT * FROM DKR9";

                    // Создаем MySqlDataAdapter и задаем запрос SELECT и соединение
                    DataBase.msCommand.CommandText = query;
                    DataBase.msDataAdapter.SelectCommand = DataBase.msCommand;

                    // Заполните DataTable данными из базы данных
                    DataBase.msDataAdapter.Fill(dataTable);

                    // Привязка таблицы DataTable к DataGridView
                    dataGridUS.DataSource = dataTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при загрузке данных: " + ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    // Закрыть соединение с базой данных
                    DataBase.CloseDB();
                }
            }
            else
            {
                MessageBox.Show("Ошибка соединения с БД", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
