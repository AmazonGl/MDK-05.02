﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DKR9
{     
    internal class Login
    {
        static public string Role, familia, User;

        static public void Logins(string login, string password)
        {
            try
            {
                DataBase.msCommand.CommandText = @"SELECT name_role from sp_role, account WHERE Login = '" + login + "' and Password = '" + password + "' and account.id_role=sp_role.id_role ";
                Object result = DataBase.msCommand.ExecuteScalar();
                if (result != null)
                {
                    Role = result.ToString();
                    User = login;
                }
                else
                {
                    Role = null;
                    familia = null;
                }    
            }
            catch 
            {
                Role = User = null;
                MessageBox.Show("Ошибка при входе!");
            
            }
        }

        static public string LoginName(string login)
        {
            try
            {
                DataBase.msCommand.CommandText = @"SELECT Familia FROM account WHERE Login = '" + login + "' ";
                Object result = DataBase.msCommand.ExecuteScalar();
                familia = result.ToString();
                return familia;
            }
            catch
            {
                return null;
            }
        }
    }
}
